#! /usr/bin/sh

					mkdir /media/mydrive-himani
					mount 192.168.43.47:/cloud/himani /media/mydrive-himani
					