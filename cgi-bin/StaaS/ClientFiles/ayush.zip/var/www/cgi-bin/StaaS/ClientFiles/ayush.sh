#! /usr/bin/sh

					mkdir /media/mydrive-ayush
					mount 192.168.43.47:/cloud/ayush /media/mydrive-ayush
					