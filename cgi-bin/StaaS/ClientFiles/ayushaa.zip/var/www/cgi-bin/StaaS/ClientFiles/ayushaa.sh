#! /usr/bin/sh

					mkdir /media/mydrive-ayushaa
					mount 192.168.43.47:/cloud/ayushaa /media/mydrive-ayushaa
					